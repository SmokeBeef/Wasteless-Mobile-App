import { View, Text } from 'react-native'
import React from 'react'

const SearchBar = () => {
  return (
    <View>
      <Text>SearchBar</Text>
    </View>
  )
}

export default SearchBar