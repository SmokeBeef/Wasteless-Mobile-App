import Logo from "./icon/Logo";

export {Logo}