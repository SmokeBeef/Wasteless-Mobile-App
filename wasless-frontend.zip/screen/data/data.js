export const data = [
    {
        nama: "Kursi Merah Plastik",
        penyewa: "Diana Agnesia",
        jarak: "1.5 Km",
        rating: "4/5",
        like: 10,
        img: require("../../assets/images/fn1.jpg"),
        iLike: true
    },
    {
        nama: "Sofa",
        penyewa: "Diana Agnesia",
        jarak: "1.5 Km",
        rating: "4/5",
        like: 10,
        img: require("../../assets/images/fn2.jpg"),
        iLike: false
    },
    {
        nama: "Vas Bunga",
        penyewa: "Diana Agnesia",
        jarak: "1.5 Km",
        rating: "4/5",
        like: 10,
        img: require("../../assets/images/fn3.jpg"),
        iLike: false
    },
    {
        nama: "Meja putih asdoamKA asDMAdoafbiaUbsfiJABfi",
        penyewa: "Diana Agnesia",
        jarak: "1.5 Km",
        rating: "4/5",
        like: 10,
        img: require("../../assets/images/fn4.jpg"),
        iLike: false
    },
    
]