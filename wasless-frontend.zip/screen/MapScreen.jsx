import { View, Text } from 'react-native'
import React from 'react'

const MapScreen = () => {
  return (
    <View>
      <Text>MapScreen</Text>
    </View>
  )
}

export default MapScreen