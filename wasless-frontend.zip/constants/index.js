
import { COLORS,  SIZES, SHADOWS, FONT_FAMILY} from "./theme";

export { COLORS,  SIZES, SHADOWS, FONT_FAMILY};
